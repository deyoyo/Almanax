package enums;

public interface SuperType {
    String getUrl(Language lg);
}
